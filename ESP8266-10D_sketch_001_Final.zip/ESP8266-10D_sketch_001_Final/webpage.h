
char const HTTP_HEADER[] = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n";


// all the below can br minimised

char const HTML_1[]  = R"=="==( 
<html lang='en'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>
<meta name='viewport' content='width=device-width, initial-scale=0.80, user-scalable=yes'>
<title>IOT Monitor</title>
<style>
  body     { background-color: #ffffff; font-size: 100% }
  #outer   { padding: 5px 10px 5px 10px;}
  #wrapper { width: 430px; margin: 10px auto;  padding: 10px;  text-align:center;   border: 2px solid blue;   border-radius: 15px;  }
  h1       { margin: 0 auto 0 auto;}
  h2       { text-align: center;}
  h3       { margin: 0px 0px 5px 0px; }
  #tC      { display: flex; align-items: center;  justify-content: center;   Margin: 1em auto 1em auto;}
  #tC2     { text-align: center;  margin-right: 2.5em;  }
  #time    { display: inline; font-size: 300%;   }
  #dC      { display:inline-block;   margin: 0px auto 0px auto; width: 100%; }
  #dial_1  { display:inline-block; float: left; }
  #dial_2  { display:inline-block; float: right; }
  canvas   { background-color: #ffffff;    }
  .bigText { font-size: 150%;}  
  .noMargin{ margin: 0px 0px 0px 0px; }
  #gC      { display:inline-block;  text-align:center; margin: 20px auto 0px auto;  }
  #key     { width: 50%; padding-top: 10px; float: left; text-align: left;} 
  .box     { float: left;  height: 15px;  width:10px;  margin: 0px 10px 0px 0px; clear: both;     }
  .red     { background-color: red; }
  .blue    { background-color: blue; }
</style>
</head>

<body >
<div id='outer'>
    <div id='wrapper'>
      <h1>Temperature &amp; Humidity</h1>

      <div id='tC'>
          <div id='tC2'>
          <div id='brightnessIcon'><!--?xml version='1.0' encoding='UTF-8'?-->  <svg xmlns='http://www.w3.org/2000/svg' xml:space='preserve' width='25mm' height='25mm' version='1.1' viewBox='0 0 2500 2500' xmlns:xlink='http://www.w3.org/1999/xlink'> <defs> <style type='text/css'>  .str0 {stroke:#aaaaaa; stroke-width:20.00} .str1 {stroke:#aaaaaa; stroke-width:7.5} .str2 {stroke:#aaaaaa; stroke-width:15.00} .fil0 {fill:black} .fil1 {fill:yellow} .fnt0 {font-weight:normal;font-size:400px;font-family:'Verdana'}  </style> </defs> <g id='Layer_x0020_1'> <circle class='fil1 str2' cx='1250' cy='1250' r='680'></circle><rect class='fil1 str0' transform='matrix(0.133299 -0.23088 0.246464 0.142296 1562.82 538.757)' width='1604' height='595' rx='280' ry='280'></rect><rect class='fil1 str0' transform='matrix(0.23088 -0.133299 0.142296 0.246464 1876.53 790.456)' width='1604' height='595' rx='280' ry='280'></rect><rect class='fil1 str1' x='2022' y='1165' width='428' height='169' rx='75' ry='80'></rect><rect class='fil1 str0' transform='matrix(-0.23088 -0.133299 0.142296 -0.246464 2246.87 1923.36)' width='1604' height='595' rx='280' ry='280'></rect><rect class='fil1 str0' transform='matrix(-0.133299 -0.23088 0.246464 -0.142296 1776.64 2331.58)' width='1604' height='595' rx='280' ry='280'></rect><rect class='fil1 str0' transform='matrix(-2.11373E-014 0.266598 -0.284592 -2.25059E-014 1334.71 2022.37)' width='1604' height='595' rx='280' ry='280'></rect><rect class='fil1 str0' transform='matrix(0.133299 -0.23088 0.246464 0.142296 576.632 2246.88)' width='1604' height='595' rx='280' ry='280'></rect> </g></svg></div>
          <div id='label'>Brightness</div>
        </div>
        <span id='time'>6:27:11 PM</span>
      </div>

       <div id='dC'> 
         <div id='dial_1'> 
           <h3>Temperature</h3>
           <canvas id='canvasTemp' width='200' height='150' style='border:1px solid #000000;'> </canvas>
           <p class='noMargin bigText'><span id='temp'>--&deg;C</span></p>
         </div>    

         <div id='dial_2'> 
           <h3>Humidity</h3>
           <canvas id='canvasHumid' width='200' height='150' style='border:1px solid #000000;'> </canvas>
           <p class='noMargin bigText'><span id='humd'>--%</span></p>
         </div>
       </div>  <!--  'dC'  -->
     
       <div id='gC'> 
         <canvas id='graph' width='430' height='200' style='border:1px solid #000000; background-color:white;'> </canvas>
         <div id='key'>
           <div> <div class='box red'></div> Temperature</div>
           <div> <div class='box blue'></div> Humidity</div>
         </div>   
       </div>      
    </div> <!--  'wrapper'  -->
   </div> <!--  outer  --> 
</body>

<script type='text/javascript'>
// <![CDATA[


function processReceivedData(evt) 
{
  // new data has been received via the websocket
  var data = evt.data;
  console.log(data);

  // the data is a single string. Data is | separated so use the bar character to split the data in to array elements.
  var tmp = data.split('|');

  // convert the received values in to numbers
  var h  = parseInt(tmp[0]);
  var tc = parseFloat(tmp[1]);
  var tf = parseFloat(tmp[2]);
  var b  = parseInt(tmp[3]);

  var whichTemp = (tmp[4]);   //  (C or F)
  
 // if the temperature scale has changed reset all the values used for the graph.
 // I am reseting humidity as well as temperature.

 if ( oldTemp != whichTemp  )
 {
    tempArray = [ -9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999 ];
    humdArray = [ -9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999 ];
    oldTemp = whichTemp;
 }

  // the brightness value uses the same range everytime so we can draw the sun logo
  drawSVG(b);

  // the humidity value use the same range everytime so we can draw the humidity dial
  var arcStartDegree = 160;
  var arcStopDegree = 20;
  
  var dialMinVal = 0;
  var dialMaxVal = 100;

  // humidity dial
  drawDial('canvasHumid', '#aaaaff', arcStartDegree, arcStopDegree, dialMinVal, dialMaxVal, h);   
  document.getElementById('humd').innerHTML = h + '%';


  // temperature dial.  If using Celsius the range is -30 to 50.   If using Fahrenheit the range is 20 to 120. 
  var tempSymbol = '';
  var temperature = 0;
  
  if (whichTemp=="C") 
  { 
    dialMinVal = -30;
    dialMaxVal = 50;
    temperature = tc;
    tempSymbol = '&deg;C';
  }
  else
  {
    dialMinVal = 20;
    dialMaxVal = 120;
    temperature = tf;
    tempSymbol = '&deg;F';
  }
  drawDial('canvasTemp',  '#ffaaaa', arcStartDegree, arcStopDegree, dialMinVal, dialMaxVal, temperature); 
  document.getElementById('temp').innerHTML = temperature + tempSymbol;

  // graph
  // remember to take in to account both the humidity and the temperature ranges 
  
  var graphCanvas = 'graph';
  var drawDataPoints = true;
  var graphMin = 0;
  var graphMax = 0;
      
  if (whichTemp=="C") 
  { 
      graphMin = -30;
      graphMax = 100;
      temperature = tc;
  }
  else // temperature is in F
  {
      graphMin = 0;
      graphMax = 120;
      temperature = tf;
  }
      
  drawGraph(graphCanvas, graphMin, graphMax, drawDataPoints, temperature, h);
}




// ===========================================  DIAL  =========================================

function drawDial(canvasID, dialColour, startAngle, stopAngle, minVal, maxVal, dialValue)
{
  oneDegreeInRadians = Math.PI/180;
  if (stopAngle < startAngle) { stopAngle = stopAngle + 360;}

  let arcStartAngleInRadians =  oneDegreeInRadians * (startAngle-5)  ;
  let arcStopAngleInRadians  =  oneDegreeInRadians * (stopAngle+5) ;  

  var c = document.getElementById(canvasID);
  var ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  ctx.save();
  
  let H = c.height;
  let W = c.width;
  
  let arcLineWidth = W/5;
  ctx.translate(W/2, W/2);        // move coordinates 0,0 to the centre of the canvas
  
  // draw arc
  ctx.beginPath();
  let radius = W/2 - (arcLineWidth/2) - (W/100);      
  ctx.lineWidth = arcLineWidth;
  ctx.lineCap = 'butt';
  ctx.strokeStyle = dialColour;
  ctx.arc(0, 0, radius, arcStartAngleInRadians, arcStopAngleInRadians, false);
  ctx.stroke();

  
  // draw centre circle
  ctx.beginPath();
  let centerCircleRadius = W/100*3.5
  ctx.strokeStyle = '#000000';
  ctx.fillStyle = '#222222';
  ctx.lineWidth = 2;
  ctx.arc(0, 0, centerCircleRadius, 0, 2 * Math.PI, true);
  ctx.stroke();
  ctx.fill();
  

  // draw ticks 
  ctx.beginPath();
  ctx.lineWidth = 1;
  ctx.lineCap = 'butt';
  ctx.strokeStyle = '#333333';

  ctx.font = '12px Arial';
  ctx.fillStyle = '#333333';
  ctx.textAlign = 'center'; 
  ctx.textBaseline = 'top'; 

  let tickStartPoint = radius - (arcLineWidth/2) ;   // bottom of the arc
  let tickLength =  5/8 * arcLineWidth - 5; 
  
  let labelPos = radius + (arcLineWidth/2) - 2; 

  for (let angle=minVal; angle<=maxVal; angle = angle+10)
  {   
    let angleInDegrees =  (angle-minVal) *  ((stopAngle - startAngle) / (maxVal - minVal)) + startAngle  ;
    let angleInRadians = angleInDegrees * oneDegreeInRadians;

    ctx.rotate(angleInRadians );  
    ctx.moveTo(tickStartPoint, 0 );                   
    ctx.lineTo(tickStartPoint + tickLength, 0 );
    ctx.stroke();
    
    // draw the label at the right angle.
    // rotate the dial - 90 degree, draw the text at the new top of the dial, then rotate +90.
    // this means we use the - y axis.
    
    ctx.rotate(90*oneDegreeInRadians); 
    ctx.fillText(angle.toString(), 0, -labelPos );        
    ctx.rotate(-90*oneDegreeInRadians); 
    
    ctx.rotate(-angleInRadians);  //  this puts the dial back where it was.     
  }


  // draw the pointer
  
  // map the value to a degree
  let pointerAngleInDegrees =  (dialValue-minVal) *  ((stopAngle - startAngle) / (maxVal - minVal)) + startAngle  ;
  let pointerAngleInRadians = pointerAngleInDegrees * oneDegreeInRadians;

  let pointerLength = radius*0.86;
  let pointerWidth = W/100 * 2; 
  
  ctx.beginPath();
  ctx.lineWidth = pointerWidth;
  ctx.lineCap = 'round';  
  ctx.moveTo(0,0);
  ctx.rotate(pointerAngleInRadians);
  ctx.lineTo(pointerLength, 0);
  ctx.stroke();
  ctx.rotate(-pointerAngleInRadians);

  // reset the coordinates ready for next time    
  ctx.restore();
  
}



// ===========================================  GRAPH  =========================================

function drawGraph(canvasID, gMin, gMax, drawDataPoints, t,h )
{

  // Graph Init - draw the graph but do not draw values.

  var c = document.getElementById(canvasID);
  var ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height); 

  var graphWidth  = c.width;
  var graphHeight = c.height; 
    
  var fontSize = '10px Arial';
  var fontAdjust = 3;
  if (graphHeight < 100) { fontSize = '6px Arial'; fontAdjust = 1;}
  
  var numySteps = gMax - gMin;
  if (numySteps > 10) { numySteps = numySteps /10; }
  var numxSteps = 20;

  var xStep = graphWidth / numxSteps;
  var yStep = graphHeight / numySteps;


  ctx.lineWidth = 1;
  ctx.strokeStyle = '#e5e5e5';
  ctx.lineCap = 'butt';
      for (let x = 0; x < c.width; x=x+xStep) 
  { 
     ctx.moveTo(x, 0);    ctx.lineTo(x, c.height);     ctx.stroke();
  }

      for (let y = 0; y <= numySteps; y++) 
  { 
     let yPos = y * yStep;
     ctx.moveTo(0, yPos);    ctx.lineTo(c.width,yPos);    ctx.stroke();
  }
  
  // draw labels    
  ctx.font = fontSize;
  ctx.fillStyle = '#000000';
   
  // no need to draw the first or the last label
  for (let i = 1; i < numySteps; i++)
  {
       let yPos = c.height - i * yStep;
       let tmp = i * 10;
       tmp = tmp + gMin;
       let txt = tmp.toString();
       ctx.fillText(txt, 2, yPos + fontAdjust);        
  }

  
  // draw the  values on the graph  
  if (drawDataPoints)
  {
      tempArray.shift();  tempArray[19] = t;
      humdArray.shift();  humdArray[19] = h;
  
      // Temperature        
      ctx.beginPath();
      ctx.lineWidth = 1;  
      ctx.strokeStyle = '#ff7777';  
      ctx.fillStyle   = '#ff4444';  
  
      // on the first value we are not coming from an existing point so we just need to move to the coordinates ready to plot value 2.
      let firstValue = true;

      for (let i = 0; i < numxSteps; i++) 
      { 
          if (tempArray[i] != -9999) 
          {
              let tmpVal = tempArray[i] ;
              let yPos = (tmpVal - gMin) * (graphHeight - 0)/( gMax - gMin ) + 0;
              yPos = graphHeight - yPos;
              let xPos = (i*xStep) + xStep;
              
              // draw the line
              if (firstValue)   {  ctx.moveTo(xPos, yPos);  firstValue = false;  }
              else              {  ctx.lineTo(xPos,yPos);   ctx.stroke();  }
          
              // draw the dot
              ctx.beginPath();  ctx.arc(xPos, yPos, 3, 0, 2 * Math.PI, false);  ctx.fill();
          }
      }

    
      // Humidity
      ctx.lineWidth = 1;  
      ctx.strokeStyle = '#7777ff';  
      ctx.fillStyle   = '#4444ff';    
      ctx.beginPath();
  
      // on the first value we are not coming from an existing point so we just need to move to the coordinates ready to plot value 2.
      firstValue = true;

      for (let i = 0; i < numxSteps; i++) 
      { 
          if (humdArray[i] != -9999) 
          {
              let tmpVal = humdArray[i] ;
              let yPos = (tmpVal - gMin) * (graphHeight - 0)/( gMax - gMin ) + 0;
              yPos = graphHeight - yPos;
              let xPos = (i*xStep) + xStep;
              
              // draw the line
              if (firstValue)   {  ctx.moveTo(xPos, yPos);  firstValue = false;  }
              else              {  ctx.lineTo(xPos,yPos);   ctx.stroke();  }
    
              // draw the dot
              ctx.beginPath();  ctx.arc(xPos, yPos, 3, 0, 2 * Math.PI, false);  ctx.fill();
          }
      }

  } // if (! initOnly)
} // function drawGraph


// ===========================================  SUN  =========================================
function drawSVG(brightnessVal)
{
  // create the sun icon
  // the number of rays represents the brightness value from 0 to 12

  // update the numeric value (may or may not be shown). When the numeric value is not used this bit is ignored
  var SVGicon = svgArray[0].replace('[bright]', brightnessVal);
  for (var i=1; i <= brightnessVal; i++)  { SVGicon = SVGicon + svgArray[i];  }
  document.getElementById('brightnessIcon').innerHTML = SVGicon;
}


function updateTime() 
{  
   var d = new Date();
   var t = d.toLocaleTimeString();
   document.getElementById('time').innerHTML = t;
}


// This is executed as soon as document (web page) has finished loading.
function init() 
{
  Socket = new WebSocket('ws://' + window.location.hostname + ':81/');
  Socket.onmessage = function(event) { processReceivedData(event); };

  Socket.onopen = function()    { console.log('WS open');  Socket.send('#'); }
  //Socket.onclose = function() { alert('Websocket closed');  }
  Socket.onerror = function()   { alert('Websocket error!');  }

  // myVarTime is a timer used to update the time displayed in the page.
  // when the timer fires it calls the function updateTime()
  var myVarTime = setInterval(updateTime, 1000); 
  
  console.log('started');
}



var Socket;

// arrays to hold the temperature and humidity values.
var tempArray = [ -9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999 ];
var humdArray = [ -9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999,-9999 ];
var oldTemp = "";
var t = 0;
var h = 0;
var b = 0;

// arrays to hold the svg data for the sun icon
// the svg data could be made more efficient.
var svgArray = [];
svgArray[0] = "<?xml version='1.0' encoding='UTF-8'?> <!DOCTYPE svg PUBLIC '-//W3C//DTD SVG 1.1//EN' 'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd'> <svg xmlns='http://www.w3.org/2000/svg' xml:space='preserve' width='25mm' height='25mm' version='1.1' viewBox='0 0 2500 2500'   xmlns:xlink='http://www.w3.org/1999/xlink'> <defs> <style type='text/css'> <![CDATA[ .str0 {stroke:#aaaaaa; stroke-width:20.00} .str1 {stroke:#aaaaaa; stroke-width:7.5} .str2 {stroke:#aaaaaa; stroke-width:15.00} .fil0 {fill:black} .fil1 {fill:yellow} .fnt0 {font-weight:normal;font-size:400px;font-family:'Verdana'} ]]> </style> </defs> <g id='Layer_x0020_1'> <circle class='fil1 str2' cx='1250' cy='1250' r='680'/>";
//svgArray[0] = svgArray[0] + "<text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' class='fil0 fnt0'>[bright]</text>";
svgArray[1] = "<rect class='fil1 str0' transform='matrix(0.133299 -0.23088 0.246464 0.142296 1562.82 538.757)' width='1604' height='595' rx='280' ry='280'/>";
svgArray[2] = "<rect class='fil1 str0' transform='matrix(0.23088 -0.133299 0.142296 0.246464 1876.53 790.456)' width='1604' height='595' rx='280' ry='280'/>";
svgArray[3] = "<rect class='fil1 str1' x='2022' y='1165' width='428' height='169' rx='75' ry='80'/>";
svgArray[4] = "<rect class='fil1 str0' transform='matrix(-0.23088 -0.133299 0.142296 -0.246464 2246.87 1923.36)' width='1604' height='595' rx='280' ry='280'/>";
svgArray[5] = "<rect class='fil1 str0' transform='matrix(-0.133299 -0.23088 0.246464 -0.142296 1776.64 2331.58)' width='1604' height='595' rx='280' ry='280'/>";
svgArray[6] = "<rect class='fil1 str0' transform='matrix(-2.11373E-014 0.266598 -0.284592 -2.25059E-014 1334.71 2022.37)' width='1604' height='595' rx='280' ry='280'/>";
svgArray[7] = "<rect class='fil1 str0' transform='matrix(0.133299 -0.23088 0.246464 0.142296 576.632 2246.88)' width='1604' height='595' rx='280' ry='280'/> ";
svgArray[8] = "<rect class='fil1 str0' transform='matrix(0.23088 -0.133299 0.142296 0.246464 168.409 1776.64)' width='1604' height='595' rx='280' ry='280'/>";
svgArray[9] = "<rect class='fil1 str1' x='50' y='1165' width='428' height='169' rx='75' ry='80'/>";
svgArray[10] = "<rect class='fil1 str0' transform='matrix(-0.23088 -0.133299 0.142296 -0.246464 538.753 937.178)' width='1604' height='595' rx='280' ry='280'/>";
svgArray[11] = "<rect class='fil1 str0' transform='matrix(-0.133299 -0.23088 0.246464 -0.142296 790.452 623.465)' width='1604' height='595' rx='280' ry='280'/>";
svgArray[12] = "<rect class='fil1 str0' transform='matrix(-2.11373E-014 0.266598 -0.284592 -2.25059E-014 1334.71 50.0007)' width='1604' height='595' rx='280' ry='280'/>";

document.addEventListener('DOMContentLoaded', init, false);


// ]]>
</script>
  
  
</html> 
)=="==";
